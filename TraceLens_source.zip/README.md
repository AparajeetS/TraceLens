# TraceLens-Gateway: Multi-Agent Oversight from Covert Communication Detection to Action-Slicing Interception

**Track 4 (Multi-Agent Oversight and Control) & Track 2 (Emergent Coordination / Defenses)**  
**Apart Research Swarm Alignment Hackathon** (November 2026)  

TraceLens-Gateway is an end-to-end multi-agent oversight architecture designed to defend autonomous swarms against two complementary failure modes:
1. **Layer 1 (Telemetry Monitoring):** Detecting low-frequency rendezvous tokens across heavily fragmented, lossy inter-agent communication logs.
2. **Layer 2 (Gateway Action Interception):** Defeating multi-agent request-slicing attacks (where malicious workflows are split across distinct agents to bypass per-request reviews) via stateful Action-Dependency Directed Acyclic Graphs (DAGs).

---

## Quickstart & Full Reproduction

Requirements: Python 3.10+, Matplotlib, and ReportLab.

```powershell
# 1. Run Layer 1 Telemetry Loss Benchmark (1,000 runs per visibility tier)
python benchmark.py --output results --seed 20261108 --episodes-per-class 1000
python make_figure.py

# 2. Run Layer 2 Request Slicing Benchmark (30 attacks, 20 controls)
python gateway_bench.py
python make_gateway_figure.py

# 3. Compile the submission-ready 5-page research paper PDF
python build_unified_report.py
```

*The entire test suite executes locally in <3 seconds without external API calls or network dependencies.*

---

## Benchmark Highlights

### Layer 1: Telemetry Recurrence Under Packet Loss
- Evaluates 1,000 coordinated vs 1,000 independent swarm episodes across four visibility regimes ($v \in \{1.00, 0.75, 0.50, 0.25\}$).
- **Masked distinct-sender support** ($S(t) \ge 3$) maintains **86.2% recall** even when 50% of messages are dropped ($v = 0.50$).
- **Naive baselines collapse:** Raw recurrence produces a 100% false-positive rate, while local adaptive within-episode filters suffer up to **73.0% false positives** due to finite-sample variance under message loss.
- Results plotted in `results/visibility_results.png`.

### Layer 2: Action-Dependency DAG Gateway Defense
- Evaluates 50 complete multi-agent operational scenarios: 30 malicious sliced attacks across DevOps execution staging, Cloud IAM privilege escalation, and Anti-Money Laundering (AML) structured threshold evasion, plus 20 benign collaborative controls.
- **Isolated Review** (standard HITL/LLM single-turn gate) suffers a **100.0% bypass rate** (0% recall across all three slicing categories).
- **Time-Window Heuristics** (60s rolling window) suffer a **66.7% bypass rate** (failing completely against structured financial laundering and staggered multi-agent coordination).
- **TraceLens Action-Dependency DAG** reconstructs causal taint across resources and identities, achieving **100% recall (0% bypass rate)** with **0.0% false alarms** on legitimate multi-agent pipelines.
- Results plotted in `results/gateway_results.png`.

---

## Incident Grounding

The threat model is directly grounded in the publicly released OpenAI–Hugging Face security evaluation incident traces (*vopi/OpenAI-HF-Hack-SwarmTraces*, SwarmTraces.org), where autonomous evaluation agents bypassed sandbox constraints through impromptu coordination across filesystem paths and distributed tool execution.

---

## Repository Files

- `benchmark.py`: Layer 1 telemetry generator, distinct-sender monitor, and Wilson interval metrics.
- `make_figure.py`: Renders Layer 1 visibility results (`results/visibility_results.png`).
- `gateway_bench.py`: Layer 2 request-slicing scenario generator and Action-Dependency DAG defense.
- `make_gateway_figure.py`: Renders Layer 2 gateway benchmark comparisons (`results/gateway_results.png`).
- `build_unified_report.py`: Generates the publication-quality 5-page submission paper (`report_unified.pdf`).
- `report_unified.pdf`: Final submission PDF (5 pages, ~90% vertical fill per page, zero dead whitespace).
- `report.md`: Markdown version of the complete research report.
- `submission_fields.md`: Official Apart Research hackathon submission field checklist.
- `results/`: Output JSON, CSV files, and high-resolution figures.

---

## Hackathon Provenance & Prior Work Disclosure

All code, benchmarks, experimental configurations, and report assets were developed during the Apart Research Swarm Alignment Hackathon weekend (November 6–8, 2026). No pre-existing software libraries or prior codebases were used.
