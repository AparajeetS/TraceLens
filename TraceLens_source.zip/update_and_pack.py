import zipfile, os
from pathlib import Path

tracelens_dir = Path(r"C:\Users\apara\Documents\Codex\2026-11-08\https-apartresearch-com-sprints-swarm-alignment\outputs\TraceLens")

# Update submission_fields.md
sub_fields = tracelens_dir / "submission_fields.md"
if sub_fields.exists():
    content = sub_fields.read_text(encoding="utf-8")
    content = content.replace("Upload file: `report_unified.pdf` (5 pages", "Upload file: `report_unified.pdf` (8 pages")
    content = content.replace("- **Name:** *[Your Full Name]*", "- **Name:** Aparajeet Shadangi")
    sub_fields.write_text(content, encoding="utf-8")
    print("Updated submission_fields.md")

# Update report.md
report_md = tracelens_dir / "report.md"
if report_md.exists():
    rmd = report_md.read_text(encoding="utf-8")
    rmd = rmd.replace("TraceLens Team", "Aparajeet Shadangi")
    report_md.write_text(rmd, encoding="utf-8")
    print("Updated report.md")

# Rebuild TraceLens_source.zip
zip_path = tracelens_dir / "TraceLens_source.zip"
with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
    for root, dirs, files in os.walk(tracelens_dir):
        dirs[:] = [d for d in dirs if d not in [".git", "__pycache__", ".venv", "build"]]
        for file in files:
            if file == "TraceLens_source.zip":
                continue
            fp = Path(root) / file
            arcname = fp.relative_to(tracelens_dir)
            zf.write(fp, arcname)

print(f"Rebuilt {zip_path} (size: {zip_path.stat().st_size / 1024:.1f} KB)")
